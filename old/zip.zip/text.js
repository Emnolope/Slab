let string1="[SYS]


SYS Formalize systems more         ,1Nx MED`
+ |PRB_chakramiss
SYS Find smart diff alg            ,iNx IDE`
Query: Diff {ChatGPT}
Algorithm Better CopyPasteMoveEdit BlockEdit Detection
Now: SemanticMerge SimTexter(Sim_Text) CacycleDiff
App: BeyondCompare SemanticMerge WinMerge Meld SDSmartDifferencer
Tech: LeastLevenstheinDifferences Myers  WalterTichy PaulHecke Equality LCS
https://prettydiff.com/2/guide/unrelated_diff.xhtml
'git diff --color-moved --color-moved-ws=allow-indentation-change HEAD^..HEAD'
https://tiarkrompf.github.io/notes/?/diff-algorithm/
http://cacycle.altervista.org/wikEd-diff-tool.html
https://en.wikipedia.org/wiki/User:Cacycle/diff

SYS Start following RTN again      U1Mx RTN`
//SYS Re order do list                IDE,PRN
SYS Calendar Multifrequency      ide ! ciNx(-long term trigger)???
Between Strong paper, Custom cards, Modified paper, and handwriting, STRONG PAPER comes out on top.
SYS Reprint LIT on Terraslate      cImx AMZ`
###########################################